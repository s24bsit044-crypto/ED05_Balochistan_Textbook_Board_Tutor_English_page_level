---
title: Board Textbook Tutor
emoji: 📚
colorFrom: green
colorTo: blue
sdk: gradio
sdk_version: 4.44.0
app_file: app.py
pinned: false
---

# ED-05 · Textbook RAG Tutor with Page-Level Citation

Retrieval-augmented revision tutor for Balochistan Textbook Board (Grades 9–12) books.
**BM25 + fine-tuned multilingual-E5 → RRF hybrid retrieval → cited reader that abstains when retrieval is weak.**
Citations are built from chunk metadata (book, chapter, page), so the model cannot invent a page number.

## Repo layout
| Path | Purpose |
|---|---|
| `notebooks/ED05_Textbook_RAG_Tutor.ipynb` | Research pipeline: chunking comparison, synthetic queries, fine-tuning, evaluation |
| `ed05_tutor/` | Importable package (chunking, hybrid retrieval, cited reader) |
| `scripts/build_index.py` | Build the index from `data/passages.jsonl` |
| `scripts/upload_to_hf.py` | Push fine-tuned model + private index to Hugging Face |
| `app.py` | Gradio app (deployment entry point) |
| `Dockerfile`, `docker-compose.yml` | Container deployment |
| `requirements*.txt` | runtime / training / CI dependencies |
| `tests/`, `.github/workflows/ci.yml` | Unit tests + GitHub Actions |

## ⚠️ Copyright rule
Never commit textbook text. `data/`, `pdfs/`, `index/` (its `chunks.jsonl` contains book text), `*.npy`, `*.pkl` are in `.gitignore`.
Host the index in a **private** repo/volume only.

## Quick start (local)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # edit values
# put passages.jsonl etc. in data/
python scripts/build_index.py --data data --out index --model intfloat/multilingual-e5-base
python app.py                   # http://localhost:7860
```
For best accuracy, run the notebook on a Colab T4 first, then use the fine-tuned model
(`--model outputs/e5_ft`) and the calibrated threshold (`--abstention outputs/abstention.json`).

## Share on GitHub
```bash
git init && git add . && git commit -m "Initial commit: ED-05 textbook RAG tutor"
git branch -M main
git remote add origin https://github.com/<you>/ed05-textbook-rag-tutor.git
git push -u origin main
```
Check `git status` first: no `data/`, `index/`, `pdfs/` or `.env` should appear.

## Deploy

### Option A - Hugging Face Spaces (easiest)
1. Upload artifacts once (private index, model):
   ```bash
   export HF_TOKEN=hf_xxx
   python scripts/upload_to_hf.py --model-dir outputs/e5_ft --model-repo <you>/ed05-e5-ft \
                                  --index-dir index --index-repo <you>/ed05-index
   ```
2. Create a new Space (SDK: Gradio) and push this repo to it (`git push space main`).
3. Space → Settings → **Secrets/Variables**: `HF_TOKEN`, `HF_INDEX_REPO=<you>/ed05-index`,
   `DENSE_MODEL=<you>/ed05-e5-ft`, `READER_MODE=extractive` (free CPU) or `llm` (needs GPU hardware).

### Option B - Docker (any VPS / cloud)
```bash
docker compose up --build        # mounts ./index and ./pdfs read-only
```

### Option C - Colab demo
Run the notebook; the last cell launches Gradio with `share=True`.

## Reader modes
- `extractive` (default): returns the best sentences of the top passage; no hallucination, runs on CPU.
- `llm`: `Qwen/Qwen2.5-3B-Instruct` constrained to retrieved passages (use a GPU; or set `READER_MODEL=Qwen/Qwen2.5-1.5B-Instruct` for CPU).

## Evaluation honesty
Numbers from synthetic questions are a **proxy**. Report teacher-gold results (notebook Cell 14) separately.

## Tests
```bash
pip install -r requirements-dev.txt && pytest -q
```
