"""Structural chunking (Example+Solution kept together) and fixed-window baseline."""
import re
from collections import defaultdict

SENT_END = tuple(".?!:;)")
HEAD_WORDS = {"Example", "Exercise", "Activity", "Experiment", "Summary"}
SKIP_BEFORE = {"in", "see", "of", "to", "from", "and", "the", "at", "on", "by", "with", "chapter", "unit"}


def _by_book(passages):
    d = defaultdict(list)
    for p in passages:
        d[p["book_id"]].append(p)
    return d


def book_stream(book_passages):
    ps = sorted(book_passages, key=lambda p: (p["page_number"], p.get("chunk_id", 0)))
    words, pages = [], []
    for p in ps:
        w = p["text"].split()
        words += w
        pages += [p["page_number"]] * len(w)
    return words, pages


def find_boundaries(words):
    """Return sorted list of (word_index, kind, chapter_label)."""
    b, chapter, n = [], None, len(words)
    for i, w in enumerate(words):
        prev = words[i - 1] if i else ""
        sent_start = (i == 0) or prev.endswith(SENT_END) or prev.isdigit()
        wc = w.strip(".:,")
        if wc in HEAD_WORDS and sent_start:
            b.append((i, "example" if wc == "Example" else "section", chapter))
        elif wc in ("Chapter", "Unit") and i + 1 < n and words[i + 1].strip(":.").isdigit() and prev.lower() not in SKIP_BEFORE:
            label = " ".join(words[i:i + 6]).split(".")[0]
            if label != chapter:
                chapter = label
                b.append((i, "chapter", chapter))
        elif re.fullmatch(r"\d{1,2}\.\d{1,2}(\.\d{1,2})?", w) and i + 1 < n and words[i + 1][:1].isupper() and sent_start:
            b.append((i, "section", chapter))
    return b


def chapter_at(bounds, i):
    ch = None
    for j, _, c in bounds:
        if j > i:
            break
        if c:
            ch = c
    return ch


def _finalize(book_passages, words, pages, bounds, spans, strategy):
    m = book_passages[0]
    book_id, res = m["book_id"], []
    for k, c in enumerate(spans):
        if c["e"] <= c["s"]:
            continue
        res.append(dict(
            cid=f"{book_id}:{strategy}:{k}", book_id=book_id, subject=m["subject"],
            class_level=m["class_level"], book_title=m.get("book_title", book_id),
            chapter=chapter_at(bounds, c["s"]) or "Unlabeled",
            page_start=pages[c["s"]], page_end=pages[c["e"] - 1], kind=c["kind"],
            strategy=strategy, ws=c["s"], we=c["e"], text=" ".join(words[c["s"]:c["e"]]),
        ))
    return res


def structural_chunks(book_passages, min_w=80, max_w=330, max_ex=520):
    words, pages = book_stream(book_passages)
    bounds = find_boundaries(words)
    cut = sorted({0, len(words)} | {j for j, _, _ in bounds})
    kinds = {j: k for j, k, _ in bounds}
    segs = [(cut[k], cut[k + 1], kinds.get(cut[k], "text")) for k in range(len(cut) - 1)]
    chunks, cur = [], None

    def flush():
        nonlocal cur
        if cur:
            chunks.append(cur)
            cur = None

    for s, e, k in segs:
        L = e - s
        if k == "example":
            flush()
            cur = dict(s=s, e=e, kind="example")
            if L <= max_ex:
                flush()
                continue
        if cur is None:
            cur = dict(s=s, e=e, kind="text")
        elif (cur["e"] - cur["s"]) >= min_w and (cur["e"] - cur["s"]) + L > max_w:
            flush()
            cur = dict(s=s, e=e, kind="text")
        else:
            cur["e"] = e
    flush()

    out = []
    for c in chunks:
        L = c["e"] - c["s"]
        lim = max_ex if c["kind"] == "example" else max_w * 1.3
        if L <= lim:
            out.append(c)
            continue
        a = c["s"]
        while a < c["e"]:
            z = min(a + max_w, c["e"])
            while z < c["e"] and z - a < max_w + 40 and not words[z - 1].endswith(SENT_END):
                z += 1
            out.append(dict(s=a, e=z, kind=c["kind"] + "_split"))
            a = z
    return _finalize(book_passages, words, pages, bounds, out, "structural")


def fixed_chunks(book_passages, size=200):
    words, pages = book_stream(book_passages)
    bounds = find_boundaries(words)
    out = [dict(s=a, e=min(a + size, len(words)), kind="fixed") for a in range(0, len(words), size)]
    return _finalize(book_passages, words, pages, bounds, out, "fixed")


def build_chunks(passages, strategy="structural"):
    fn = structural_chunks if strategy == "structural" else fixed_chunks
    chunks = []
    for bid in sorted(_by_book(passages)):
        chunks += fn(_by_book(passages)[bid])
    return chunks
