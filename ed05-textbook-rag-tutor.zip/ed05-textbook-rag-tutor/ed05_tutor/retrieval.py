"""Hybrid retrieval: BM25 + dense (E5) fused with Reciprocal Rank Fusion."""
import collections
import json
import os
import re

import numpy as np
from rank_bm25 import BM25Okapi

tokz = lambda t: re.findall(r"\w+", t.lower())  # noqa: E731


def ctx(c):
    """Text that gets embedded: chapter context + passage."""
    return f"passage: Class {c['class_level']} {c['subject']} | {c['chapter']} | {c['text']}"


def rrf(rank_lists, k=60, w=None):
    w = w or [1] * len(rank_lists)
    sc = collections.defaultdict(float)
    for wi, rl in zip(w, rank_lists):
        for r, ci in enumerate(rl):
            sc[ci] += wi / (k + r + 1)
    return sorted(sc, key=sc.get, reverse=True)


class Index:
    def __init__(self, chunks, emb, model=None):
        self.ch, self.emb, self.model = chunks, np.asarray(emb, dtype=np.float32), model
        self.bm = BM25Okapi([tokz(c["text"]) for c in chunks])

    @classmethod
    def build(cls, chunks, model, batch_size=64):
        emb = model.encode([ctx(c) for c in chunks], batch_size=batch_size,
                           normalize_embeddings=True, show_progress_bar=True)
        return cls(chunks, emb, model)

    def save(self, path):
        os.makedirs(path, exist_ok=True)
        with open(f"{path}/chunks.jsonl", "w", encoding="utf-8") as f:
            for c in self.ch:
                f.write(json.dumps(c, ensure_ascii=False) + "\n")
        np.save(f"{path}/embeddings.npy", self.emb)

    @classmethod
    def load(cls, path, model):
        with open(f"{path}/chunks.jsonl", encoding="utf-8") as f:
            chunks = [json.loads(line) for line in f if line.strip()]
        return cls(chunks, np.load(f"{path}/embeddings.npy"), model)

    def dense_scores(self, q):
        qe = self.model.encode(["query: " + q], normalize_embeddings=True)[0]
        return self.emb @ qe

    def search(self, q, mode="hybrid", k=10):
        """Return (ranked chunk indices, top dense cosine score used for abstention)."""
        d = self.dense_scores(q)
        bm = self.bm.get_scores(tokz(q))
        dr, br = list(np.argsort(-d)[:50]), list(np.argsort(-bm)[:50])
        order = dr if mode == "dense" else br if mode == "bm25" else rrf([dr, br])
        return order[:k], float(d.max())
