"""ED-05: Textbook-board retrieval-augmented tutor with page-level citation."""
__version__ = "0.1.0"
