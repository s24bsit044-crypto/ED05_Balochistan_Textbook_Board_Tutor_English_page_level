# data/ (not tracked by git)

Place these files here locally (they are textbook-derived, so they are git-ignored):

- `passages.jsonl`
- `train.jsonl`
- `test.jsonl`
- `dataset_statistics.json`

Required fields per passage: `id, book_id, page_number, text, subject, class_level, source_file`.
