import json

REQUIRED = ["id", "book_id", "page_number", "text", "subject", "class_level", "source_file"]


def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def audit_provenance(passages):
    """Fail loudly if any passage lost its page provenance."""
    bad = [p.get("id") for p in passages if any(k not in p or p[k] in (None, "") for k in REQUIRED)]
    if bad:
        raise ValueError(f"Provenance missing for {len(bad)} passages, e.g. {bad[:3]}")
    if len({p["id"] for p in passages}) != len(passages):
        raise ValueError("Duplicate passage ids")
    return True
