"""Build the structural-chunk index.

    python scripts/build_index.py --data data --out index --model path/or/hf-id [--abstention outputs/abstention.json]

Output (chunks.jsonl contains textbook text -> keep it PRIVATE, never commit):
    index/chunks.jsonl, index/embeddings.npy, index/abstention.json
"""
import argparse
import json
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from sentence_transformers import SentenceTransformer  # noqa: E402

from ed05_tutor.chunking import build_chunks  # noqa: E402
from ed05_tutor.data import audit_provenance, read_jsonl  # noqa: E402
from ed05_tutor.retrieval import Index  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data")
ap.add_argument("--out", default="index")
ap.add_argument("--model", default="intfloat/multilingual-e5-base")
ap.add_argument("--abstention", default=None, help="abstention.json produced by the notebook (Cell 9)")
a = ap.parse_args()

passages = read_jsonl(f"{a.data}/passages.jsonl")
audit_provenance(passages)
chunks = build_chunks(passages, "structural")
print(f"{len(passages)} passages -> {len(chunks)} structural chunks")
model = SentenceTransformer(a.model)
model.max_seq_length = 256
Index.build(chunks, model).save(a.out)
if a.abstention:
    shutil.copy(a.abstention, f"{a.out}/abstention.json")
else:
    json.dump({"threshold": 0.80}, open(f"{a.out}/abstention.json", "w"))
    print("WARNING: default abstention threshold 0.80 used - calibrate with notebook Cell 9.")
print("saved to", a.out)
