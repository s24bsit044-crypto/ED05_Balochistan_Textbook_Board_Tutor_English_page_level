"""Gradio app - entry point for Hugging Face Spaces / Docker / local run."""
import glob
import json
import os

import gradio as gr
from sentence_transformers import SentenceTransformer

from ed05_tutor.config import Settings
from ed05_tutor.reader import Tutor
from ed05_tutor.retrieval import Index

S = Settings()


def ensure_index():
    if not os.path.exists(f"{S.index_dir}/chunks.jsonl"):
        if not S.hf_index_repo:
            raise SystemExit(f"No index at {S.index_dir}. Run scripts/build_index.py or set HF_INDEX_REPO.")
        from huggingface_hub import snapshot_download
        snapshot_download(S.hf_index_repo, repo_type="dataset", token=S.hf_token, local_dir=S.index_dir)


def load_tutor():
    ensure_index()
    model = SentenceTransformer(S.dense_model)
    model.max_seq_length = 256
    index = Index.load(S.index_dir, model)
    thr = json.load(open(f"{S.index_dir}/abstention.json"))["threshold"]
    return Tutor(index, thr, S.reader_mode, S.reader_model, S.top_k)


tutor = load_tutor()


def page_image(c):
    """Show the source page if the PDF is available locally (PDFs are never shipped in the repo)."""
    try:
        import fitz
        hits = glob.glob(f"{S.pdf_dir}/*{c['book_id']}*")
        if not hits:
            return None
        pix = fitz.open(hits[0])[c["page_start"] - 1].get_pixmap(dpi=110)
        path = f"/tmp/{c['book_id']}_{c['page_start']}.png"
        pix.save(path)
        return path
    except Exception:
        return None


def ui(question):
    if not question or not question.strip():
        return "Please type a question.", None, ""
    r = tutor.answer(question.strip())
    if r["abstained"]:
        return r["answer"], None, "No source"
    src = "\n".join("• " + c for c in r["citations"])
    return r["answer"], page_image(r["sources"][0]), f"📖 Source:\n{src}"


with gr.Blocks(title="Board Textbook Tutor") as demo:
    gr.Markdown("## 📚 Balochistan Board Revision Tutor\n"
                "*For revision only - not a substitute for class. Always verify against the cited page.*")
    q = gr.Textbox(label="Question (Urdu / English)")
    b = gr.Button("Ask")
    with gr.Row():
        a = gr.Textbox(label="Answer", lines=8)
        img = gr.Image(label="Source page")
    s = gr.Textbox(label="Citation")
    b.click(ui, q, [a, img, s])
    q.submit(ui, q, [a, img, s])

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=S.port)
