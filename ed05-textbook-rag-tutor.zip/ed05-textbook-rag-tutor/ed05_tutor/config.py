"""All runtime settings come from environment variables (see .env.example)."""
import os
from dataclasses import dataclass, field


def _env(name, default=None):
    v = os.environ.get(name)
    return v if v not in (None, "") else default


@dataclass
class Settings:
    # Where the built index lives (chunks.jsonl, embeddings.npy, abstention.json)
    index_dir: str = field(default_factory=lambda: _env("INDEX_DIR", "./index"))
    # Optional: pull the index from a PRIVATE Hugging Face dataset repo at startup
    hf_index_repo: str = field(default_factory=lambda: _env("HF_INDEX_REPO"))
    hf_token: str = field(default_factory=lambda: _env("HF_TOKEN"))
    # Dense retriever: HF repo id or local path of the fine-tuned model
    dense_model: str = field(default_factory=lambda: _env("DENSE_MODEL", "intfloat/multilingual-e5-base"))
    # 'llm' = generative reader, 'extractive' = no-LLM fallback (CPU friendly, zero hallucination)
    reader_mode: str = field(default_factory=lambda: _env("READER_MODE", "extractive"))
    reader_model: str = field(default_factory=lambda: _env("READER_MODEL", "Qwen/Qwen2.5-3B-Instruct"))
    # Optional local PDFs for the "source page" image (never commit these)
    pdf_dir: str = field(default_factory=lambda: _env("PDF_DIR", "./pdfs"))
    top_k: int = field(default_factory=lambda: int(_env("TOP_K", "4")))
    port: int = field(default_factory=lambda: int(_env("PORT", "7860")))
