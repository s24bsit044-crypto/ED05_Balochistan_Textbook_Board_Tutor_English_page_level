"""Cited reader. Citations come from chunk METADATA, never from model text."""
import re

SYS = ("You are a revision tutor for Balochistan Board textbooks. Answer ONLY using the numbered sources. "
       "If the sources do not contain the answer, reply exactly: NOT_IN_BOOK. "
       "Be concise (max 5 sentences), give formulas/steps if the source has them, and cite sources like [S1]. "
       "Answer in the same language as the question.")

ABSTAIN_MSG = "This question was not found in the textbooks (retrieval too weak). / یہ سوال کتابوں میں نہیں ملا۔"


def cite(c):
    s = f"{c['book_title'].split(' (')[0]}, Chapter: {c['chapter']}, p. {c['page_start']}"
    return s + (f"–{c['page_end']}" if c["page_end"] != c["page_start"] else "")


def extractive_answer(question, chunk, n=3):
    """No-LLM fallback: the n sentences of the top chunk that best overlap the question."""
    q = set(re.findall(r"\w+", question.lower()))
    sents = re.split(r"(?<=[.?!])\s+", chunk["text"])
    scored = sorted(range(len(sents)), key=lambda i: -len(q & set(re.findall(r"\w+", sents[i].lower()))))
    keep = sorted(scored[:n])
    return " ".join(sents[i] for i in keep) + " [S1]"


class Tutor:
    def __init__(self, index, threshold, reader_mode="extractive", reader_model=None, top_k=4):
        self.index, self.threshold, self.top_k = index, threshold, top_k
        self.reader_mode, self.reader_model = reader_mode, reader_model
        self._tok = self._lm = None

    def _load_reader(self):
        if self._lm is None:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
            self._tok = AutoTokenizer.from_pretrained(self.reader_model)
            dtype = torch.float16 if torch.cuda.is_available() else torch.float32
            self._lm = AutoModelForCausalLM.from_pretrained(self.reader_model, torch_dtype=dtype, device_map="auto")

    def _generate(self, question, sources):
        import torch
        self._load_reader()
        ctx_txt = "\n\n".join(f"[S{n+1}] ({cite(c)})\n{c['text'][:1500]}" for n, c in enumerate(sources))
        msgs = [{"role": "system", "content": SYS},
                {"role": "user", "content": f"Sources:\n{ctx_txt}\n\nQuestion: {question}"}]
        enc = self._tok.apply_chat_template(msgs, add_generation_prompt=True, return_tensors="pt",
                                            return_dict=True).to(self._lm.device)
        with torch.no_grad():
            out = self._lm.generate(**enc, max_new_tokens=300, do_sample=False)
        return self._tok.decode(out[0][enc["input_ids"].shape[1]:], skip_special_tokens=True).strip()

    def answer(self, question, k=None):
        k = k or self.top_k
        order, top = self.index.search(question, "hybrid", k=k)
        sources = [self.index.ch[i] for i in order]
        base = dict(question=question, top_dense=top, sources=sources)
        if top < self.threshold:
            return {**base, "answer": ABSTAIN_MSG, "citations": [], "abstained": True}
        if self.reader_mode == "llm":
            txt = self._generate(question, sources)
            if "NOT_IN_BOOK" in txt:
                return {**base, "answer": ABSTAIN_MSG, "citations": [], "abstained": True}
        else:
            txt = extractive_answer(question, sources[0])
        used = sorted({int(n) - 1 for n in re.findall(r"\[S(\d)\]", txt) if 1 <= int(n) <= len(sources)})
        return {**base, "answer": txt, "citations": [cite(sources[i]) for i in (used or [0])], "abstained": False}
