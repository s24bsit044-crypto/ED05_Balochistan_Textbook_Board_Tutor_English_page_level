import numpy as np
import pytest

from ed05_tutor.chunking import build_chunks
from ed05_tutor.data import audit_provenance
from ed05_tutor.reader import Tutor, cite, extractive_answer
from ed05_tutor.retrieval import Index, rrf


def make_passages():
    text1 = ("Chapter 1 Motion. " + "Velocity is rate of change of displacement. " * 20 +
             "Example 1.1 A car moves 10 m in 2 s. Find speed. Solution: speed = 10/2 = 5 m/s. ")
    text2 = "1.2 Newton Laws. " + "Force equals mass times acceleration. " * 30
    base = dict(book_id="b1", subject="Physics", class_level=9, book_title="Physics 9 (2026)",
                source_file="b1.pdf")
    return [dict(id="p1", chunk_id=0, page_number=1, text=text1, **base),
            dict(id="p2", chunk_id=0, page_number=2, text=text2, **base)]


def test_provenance_ok_and_fails():
    ps = make_passages()
    assert audit_provenance(ps)
    ps[0]["page_number"] = None
    with pytest.raises(ValueError):
        audit_provenance(ps)


def test_example_and_solution_stay_together():
    for c in build_chunks(make_passages(), "structural"):
        if "Example 1.1" in c["text"]:
            assert "Solution" in c["text"]


def test_chunks_keep_page_range():
    for c in build_chunks(make_passages(), "structural"):
        assert 1 <= c["page_start"] <= c["page_end"] <= 2


def test_rrf_prefers_consensus():
    assert rrf([[1, 2, 3], [3, 1, 2]])[0] == 1


class FakeModel:
    def encode(self, texts, **kw):
        return np.tile(np.array([1.0, 0.0], dtype=np.float32), (len(texts), 1))


def test_abstains_below_threshold():
    ch = build_chunks(make_passages())
    idx = Index(ch, np.tile([1.0, 0.0], (len(ch), 1)), FakeModel())
    assert Tutor(idx, threshold=2.0).answer("anything?")["abstained"]
    r = Tutor(idx, threshold=0.5).answer("What is velocity?")
    assert not r["abstained"] and r["citations"]


def test_extractive_and_cite():
    c = build_chunks(make_passages())[0]
    assert "[S1]" in extractive_answer("What is velocity?", c)
    assert "p." in cite(c)
