"""Push the fine-tuned model (public ok) and the PRIVATE index to Hugging Face.

    export HF_TOKEN=hf_xxx
    python scripts/upload_to_hf.py --model-dir outputs/e5_ft --model-repo USER/ed05-e5-ft \
                                   --index-dir index --index-repo USER/ed05-index
"""
import argparse
import os

from huggingface_hub import HfApi

ap = argparse.ArgumentParser()
ap.add_argument("--model-dir"); ap.add_argument("--model-repo")  # noqa: E702
ap.add_argument("--index-dir"); ap.add_argument("--index-repo")  # noqa: E702
a = ap.parse_args()
api = HfApi(token=os.environ["HF_TOKEN"])
if a.model_dir and a.model_repo:
    api.create_repo(a.model_repo, repo_type="model", exist_ok=True)
    api.upload_folder(folder_path=a.model_dir, repo_id=a.model_repo, repo_type="model")
if a.index_dir and a.index_repo:
    # private=True: the index contains textbook text
    api.create_repo(a.index_repo, repo_type="dataset", private=True, exist_ok=True)
    api.upload_folder(folder_path=a.index_dir, repo_id=a.index_repo, repo_type="dataset")
print("done")
